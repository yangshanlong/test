package com.airswift.restapi.online;

import com.alibaba.fastjson.JSONObject;
import com.airswift.restapi.dto.PlaceOrderDTO;
import com.airswift.restapi.utils.HttpClientUtils;
import com.airswift.restapi.utils.SignUtils;
import com.airswift.restapi.vo.HttpResponse;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;


public class OnlineDemo {
    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    //Here is the private key that needs to be the merchant
    private static final String RSA_PRIVATE_KEY = "";

    public static void main(String[] args) {
        //You can then invoke the online trading interface
        PlaceOrderDTO placeOrderDTO = new PlaceOrderDTO();
        //Your merchant id
        placeOrderDTO.setMerchantId("");
        //The merchant Order Id
        placeOrderDTO.setMerchantOrderId("");
        //The merchant Order Time yyyy-MM-dd HH:mm:ss
        placeOrderDTO.setMerchantOrderTime(sdf.format(new Date()));
        //The order Currency
        placeOrderDTO.setOrderCurrency("");
        //The order Amount
        placeOrderDTO.setOrderAmount(new BigDecimal("100"));
        //The product Detail
        placeOrderDTO.setProductDetail("");
        //The server url
        placeOrderDTO.setServerUrl("http://xxx");
        //Create signature
        String sign = SignUtils.createOnelineSign(placeOrderDTO, RSA_PRIVATE_KEY);
        placeOrderDTO.setSign(sign);
        //In response to the results
        String response = onlineTrade(placeOrderDTO);
    }

    /**
     * online transactions
     *
     * @return form
     */
    public static String onlineTrade(PlaceOrderDTO placeOrderDTO) {
        //Post requests are sent using HTTP,and the request header sets the content-type to application/json
        HttpResponse httpResponse = HttpClientUtils.reqPost("https://pag.airswift.com/tra/online/gatewayCard", placeOrderDTO, null);
        JSONObject response = httpResponse.getJsonObject();
        System.out.println("online trade response:" + response.toJSONString());
        return response.toJSONString();
    }
}
